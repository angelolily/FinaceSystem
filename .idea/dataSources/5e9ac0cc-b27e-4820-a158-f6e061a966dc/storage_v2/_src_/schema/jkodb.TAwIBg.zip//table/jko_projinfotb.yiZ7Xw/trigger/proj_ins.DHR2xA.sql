create definer = hty@`%` trigger proj_ins
    before insert
    on jko_projinfotb
    for each row
BEGIN
DECLARE s1 VARCHAR(25)character set utf8;
DECLARE s2 VARCHAR(25)character set utf8;
SET s1 = NEW.c_projstate;    
SET s2 = NEW.c_projid;  
INSERT INTO jko_operateHistor(c_prid,c_datetime,c_operate) values(s2,CURDATE(),s1);
END;

