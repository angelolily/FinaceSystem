create definer = hty@`%` trigger proj_upl
    before update
    on jko_projinfotb
    for each row
BEGIN
DECLARE s1 VARCHAR(25)character set utf8;
DECLARE s2 VARCHAR(25)character set utf8;
DECLARE s3 VARCHAR(25)character set utf8;
SET s1 = NEW.c_projstate;    
SET s2 = NEW.c_projid;
SET s3 = OLD.c_projstate;
IF s1!=s3 THEN
	INSERT INTO jko_operateHistor(c_prid,c_datetime,c_operate) values(s2,now(),s1);
END IF;
END;

